package com.cap.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {

	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private String lastName;
	private Double regFees;
	private LocalDate pDate;
	@OneToOne
	@JoinColumn(name="addFK")
	private Address address;
	
	public Customer() {
		super();
	}




	



	public Customer( String firstName, String lastName, Double regFees, LocalDate pDate) {
		super();
		//this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFees = regFees;
		this.pDate = pDate;
		//this.address = address;
	}








	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public Double getRegFees() {
		return regFees;
	}



	public void setRegFees(Double regFees) {
		this.regFees = regFees;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}

	public LocalDate getpDate() {
		return pDate;
	}


	public void setpDate(LocalDate pDate) {
		this.pDate = pDate;
	}








	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFees="
				+ regFees + ", pDate=" + pDate + ", address=" + address + "]";
	}
	
	
}