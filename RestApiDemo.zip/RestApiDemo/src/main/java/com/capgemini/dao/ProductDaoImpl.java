package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Product;

public class ProductDaoImpl implements IproductDao{
	
	private static List<Product> products=dummyDB();

	public List<Product> getAllProducts() {
	
		return products;
	}

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(1, "Samsung J9"));
		products.add(new Product(341, "Lenovo"));
		products.add(new Product(5423, "iPhone "));
		products.add(new Product(565, "Redmi 6a"));
		products.add(new Product(1001, "Sony ZL"));
		
		return products;
	}
	
	

	public List<Product> deleteProduct(int productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==productId) {
				iterator.remove();
				break;
			}
		}
		return products;
	}
	
	public List<Product> addProducts(Integer productId, String productName) {
		products.add(new Product(productId,productName));
		return products;
	}

	public Product findProducts(Integer productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId()==(productId)) {
				
				return product;	
			}
		}
		
		return null;
	}	 
	public List<Product> updateProducts(Integer productId, String productName) {
		Iterator <Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product = iterator.next();
			if(product.getProductId()==(productId)) {
				product.setProductName(productName);
				break;
			}
		}
		return products;
	} 
}
