package display;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	@Given("^dataElement$")
	public void dataelement() throws Throwable {
	    
	}

	@When("^data elements are valid$")
	public void data_elements_are_valid() throws Throwable {
	   
	}

	@Then("^display message$")
	public void display_message() throws Throwable {
	   
	}

	@Given("^query from user$")
	public void query_from_user() throws Throwable {
	    
	}

	@When("^Equipment Tag$")
	public void equipment_Tag() throws Throwable {
	   
	}

	@Then("^list$")
	public void list() throws Throwable {
	   
	}

	@When("^Quantity$")
	public void quantity() throws Throwable {
	   
	}

	@When("^Seq\\. Number$")
	public void seq_Number() throws Throwable {
	   
	}

	@When("^User Id$")
	public void user_Id() throws Throwable {
	   
	}

	@When("^Location$")
	public void location() throws Throwable {
	    
	}



}
