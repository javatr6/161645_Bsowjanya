package com.cap.model.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager =emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		
		Company cg= new Company("cg");
		Company tcs= new Company("tcs");
		
		Employee employee= new Employee(1001,"sud",LocalDate.now(),cg);
		Employee employee1= new Employee(1002,"sri",LocalDate.of(2014,11,26),tcs);
		Employee employee2= new Employee(1003,"san",LocalDate.of(2013,10,22),cg);
		Employee employee3= new Employee(1004,"sah",LocalDate.of(2011,11,21),tcs);
		
		entityManager.persist(cg);
		entityManager.persist(tcs);
		
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		
		transaction.commit();
		entityManager.close();
		

	}

}
