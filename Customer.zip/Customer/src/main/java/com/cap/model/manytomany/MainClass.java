package com.cap.model.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager =emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		
		Events java = new Events();
		java.setEventId("101_JAVA");
		java.setEventName("JAVA");
		
		Events oracle = new Events();
		oracle.setEventId("221_ORACLE");
		oracle.setEventName("ORACLE");
		
		Events dotnet = new Events();
		dotnet.setEventId("333_DOTNET");
		dotnet.setEventName("DOTNET");
		
		Delegates tom=new Delegates(1,"tom");
		Delegates tom1=new Delegates(12,"jack");
		Delegates tom2=new Delegates(19,"tom1");
		Delegates tom3=new Delegates(20,"tom2");
		Delegates tom4=new Delegates(3,"tom3");
		
		tom.getEvents().add(java);
		tom.getEvents().add(oracle);
		tom.getEvents().add(dotnet);
		
		
		tom1.getEvents().add(java);
		tom1.getEvents().add(oracle);
		
		
		entityManager.persist(tom);
		entityManager.persist(tom1);
		
		entityManager.persist(java);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		
		transaction.commit();
		entityManager.close();
		
	}

}
