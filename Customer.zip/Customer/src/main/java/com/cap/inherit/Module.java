package com.cap.inherit;


import javax.persistence.Entity;
import javax.persistence.Id;

	

		

		@Entity
		public class Module extends Project {
			@Id
			
			private String moduleName;

			public Module() {
			}
			public Module(String moduleName) {
				super();
				this.moduleName = moduleName;
			}
			public String getModuleName() {
				return moduleName;
			}
			public void setModuleName(String moduleName) {
				this.moduleName = moduleName;
			}

			}	 
		 



