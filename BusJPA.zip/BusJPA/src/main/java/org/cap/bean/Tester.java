package org.cap.bean;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



public class Tester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		
		BusBean bob=new BusBean("1615_FS","Jack","Jill","Male","Chennai",
				LocalDate.of(2017, 10,11),"jack@gmail.com","Chennai SIPCOT","Chennai MIPL","Tambaram",
				LocalTime.of(8,30),"Pending");
		
		LoginBean login=new LoginBean("Sowji","sowji123");
		
		RouteMapBean route=new RouteMapBean(01,"ChennaiMIPL,Tambaram",15,70,"TN5678","John",20);
		
		RouteMapBean route1= new RouteMapBean(02,bob,"ChennaiMIPL,Tambaram",5,
			60,"TN1234","Ramesh",30);
		
		
		bob.setRoute(route1);
		TransactionBean transactions=new TransactionBean(route,"1619_NS", LocalDate.of(2018,11,10),43.00,5000);
		entityManager.persist(bob);
		entityManager.persist(login);
		entityManager.persist(route);
		entityManager.persist(route1);
		entityManager.persist(transactions);
		transaction.commit();
		entityManager.close();

	}

} 

